import pickle

class Vehiculo:
    marca = ""
    modelo = ""
    puertas = 0

    def __init__(self, marca, modelo ,puertas):
        self.marca = marca
        self.modelo = modelo
        self.puertas = puertas

    def getMarca(self):
        return self.marca

p1 = Vehiculo("Citroen","C4",5)
print(p1.getMarca())
f = open('datos.bin', 'wb')
pickle.dump(p1, f)
f.close()
