public class bootcamp {
    public static void main(String[] args) {
        int numeroif=-1;
        int numeroWhile=0;
        String estacion="Verano";
        //*********************************
        if(numeroif>0){
            System.out.println("Positivo");
        }else if(numeroif<0){
            System.out.println("Negativo");
        }else{
            System.out.println("Cero");
        }
        //*********************************
        while(numeroWhile<3){
            numeroWhile++;
            System.out.println(numeroWhile);
        }
        //*********************************
        for(int numeroFor=0; numeroFor>3; numeroFor++){
            System.out.println(numeroFor);
        }
        //*********************************
        do{
            numeroWhile++;
            System.out.println(numeroWhile);
        }
        while(numeroWhile<3);
        //*********************************
        switch(estacion){
            case "Verano" : System.out.println("Verano");
                            break;
            case "Primavera" : System.out.println("Primavera");
                            break;
            case "Otoño" :  System.out.println("Otoño");
                            break;
            case "Invierno" : System.out.println("Invierno");
                            break;
            default:        System.out.println(estacion+" no es una estacion");
        }
    }
        //*********************************
        //Por último, para el Switch, deberás crear la variable estacion, y distintos case para las cuatro estaciones del año. 
        //Dependiendo del valor de la variable estacion se deberá mandar un mensaje por consola informando de la estación en la 
        //que está. También habrá que poner un default para cuando el valor de la variable no sea una estación.
        
    }

