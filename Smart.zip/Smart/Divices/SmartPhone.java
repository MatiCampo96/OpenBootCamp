package Smart.Divices;

import Smart.SmartDivice;

public class SmartPhone extends SmartDivice {
    @Override
    public String toString() {
        return "SmartPhone [pantalla=" + pantalla + ", megapixeles=" + megapixeles + ", marca=" + getMarca() + ", modelo=" + getModelo() + "]";
    }

    int pantalla;
    int megapixeles;

    public SmartPhone(String marca, String modelo, int bateria, int pantalla, int megapixeles) {
        super(marca, modelo, bateria);
        this.pantalla = pantalla;
        this.megapixeles = megapixeles;
    }

    public int getPantalla() {
        return pantalla;
    }

    public void setPantalla(int pantalla) {
        this.pantalla = pantalla;
    }

    public int getMegapixeles() {
        return megapixeles;
    }

    public void setMegapixeles(int megapixeles) {
        this.megapixeles = megapixeles;
    }
    
}
