package Smart.Divices;

public class Main {
    public static void main(String[] args) {
        SmartPhone SM1 =new SmartPhone("Motorola", "e3", 2000, 245, 20);
        SmartWatch SW1=new SmartWatch("Casio", "3000t", 200, "Roja", 1200);

        System.out.println(SM1.toString()+"\n"+SW1.toString());

    }
    
}
