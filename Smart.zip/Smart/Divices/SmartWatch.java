package Smart.Divices;

import Smart.SmartDivice;

public class SmartWatch extends SmartDivice{
    private String correa;
    private int hora;
    public SmartWatch(String marca, String modelo, int bateria, String correa, int hora) {
        super(marca, modelo, bateria);
        this.correa = correa;
        this.hora = hora;
    }
    public String getCorrea() {
        return correa;
    }
    public void setCorrea(String correa) {
        this.correa = correa;
    }
    public int getHora() {
        return hora;
    }
    public void setHora(int hora) {
        this.hora = hora;
    }
    @Override
    public String toString() {
        return "SmartWatch [correa=" + correa + ", hora=" + hora + ", marca=" + getMarca() + ", modelo=" + getModelo() + "]";
    }
}
