public class Nombres {
    public static void main(String[] args) {
       String[] nombres = {"Juan", "Jose", "Pepe", "Carlos"};
       String nombresTot="";
        for(String nombre : nombres){
            nombresTot=nombresTot+" "+nombre;
        }
        System.out.println(nombresTot);
    }
    
}
