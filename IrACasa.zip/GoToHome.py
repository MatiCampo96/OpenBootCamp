import time

if int(time.strftime('%H')) >= 19:
	print("Hora de ir a descansar")
else:
	print("Faltan",19 - int(time.strftime('%H')),"horas")

