public class Persona{
   private String nombre;
   public Persona(String nombre, int edad) {
    this.nombre = nombre;
    this.edad = edad;
}
public Persona(String nombre, int edad, int telefono) {
    this.nombre = nombre;
    this.edad = edad;
    this.telefono = telefono;
}
public Persona() {
}
private int edad;
   private int telefono;
public Persona(int edad, int telefono) {
    this.edad = edad;
    this.telefono = telefono;
}
public String getNombre() {
    return nombre;
}
public int getEdad() {
    return edad;
}
public int getTelefono() {
    return telefono;
}
public void setNombre(String nombre) {
    this.nombre = nombre;
}
public void setEdad(int edad) {
    this.edad = edad;
}
public void setTelefono(int telefono) {
    this.telefono = telefono;
}
@Override
public String toString() {
    return "Persona [nombre=" + nombre + ", edad=" + edad + ", telefono=" + telefono + "]";
}
public static void main(String[] args) {
    Persona persona=new Persona();
    persona.setNombre("Pedro"); 
    persona.setEdad(21);
    persona.setTelefono(1158881329);
    System.out.println(persona.toString());
    Persona persona2=new Persona("Jose", 29);
    persona2.setTelefono(1150000000);
    System.out.println(persona2.getNombre());
}

}