f = open('fichero3.txt', 'w')
f.write("Hola a\n")
f.write("Todos!\n")
f.close