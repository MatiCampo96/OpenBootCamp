from functools import reduce

def numero_impar(num):
    if num % 2!=0:
        return True

def suma(a,b):
    return a + b

numeros=[1,2,3,4,5,6,7,8,9,10]
impares=filter(numero_impar, numeros)
#print(list(impares))
res = reduce(suma, impares)
print(res)
