package proyecto.a152023;

public class Clase {
    public static void main(String[] args) {
        System.out.println("int, short, byte, long, double, float, boolean, char, String");
    }
    
}
