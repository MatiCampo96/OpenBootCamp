public class Main {
    public static void main(String[] args) {
        Cliente cliente=new Cliente();
        Trabajador trabajador= new Trabajador();

        cliente.setNombre("Julian");
        cliente.setEdad(22);
        cliente.setTelefono(1111111111);
        cliente.setCredito(200000);

        trabajador.setNombre("Jojo");
        trabajador.setEdad(23);
        trabajador.setTelefono(222222222);
        trabajador.setSalario(300000);

        System.out.println(cliente.getNombre()+" "+cliente.getEdad()+" "+cliente.getTelefono()+" "+cliente.getCredito());
        System.out.println(trabajador.getNombre()+" "+trabajador.getEdad()+" "+trabajador.getTelefono()+" "+trabajador.getSalario());

    }
}