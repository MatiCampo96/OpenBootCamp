import tkinter as tk

def Mostrar():
    if seleccion.get()==1:
        mensaje="Has seleccionado Gato"
    if seleccion.get()==2:
        mensaje="Has seleccionado perro"
    if seleccion.get()==3:
        mensaje="Has seleccionado ave"

    lblMensaje.config(text=mensaje)

def reseteo():
    for widget in ventana.winfo_children():
        if isinstance(widget, tk.Radiobutton):
            seleccion.set(None)
            lblMensaje.config(text="")

ventana = tk.Tk()
seleccion = tk.IntVar()

lblMascota = tk.Label(ventana, text="Escoge mascota:")
lblMascota.pack()

rbnGato = tk.Radiobutton(ventana, text="Gato", variable=seleccion, value=1, command=Mostrar).pack(anchor= tk.W)

rbnPerro = tk.Radiobutton(ventana, text="Perro", variable=seleccion, value=2, command=Mostrar).pack(anchor= tk.W)

rbnAve = tk.Radiobutton(ventana, text="Ave", variable=seleccion, value=3, command=Mostrar).pack(anchor= tk.W)

botonReset = tk.Button(ventana, text="Reset", command=lambda:reseteo())
botonReset.pack()
#botonReset.bind('<Botton-1>', reseteo)


lblMensaje = tk.Label(ventana)
lblMensaje.pack()
ventana.mainloop()