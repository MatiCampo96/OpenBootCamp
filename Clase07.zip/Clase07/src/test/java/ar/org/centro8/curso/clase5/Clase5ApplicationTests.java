package ar.org.centro8.curso.clase5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
