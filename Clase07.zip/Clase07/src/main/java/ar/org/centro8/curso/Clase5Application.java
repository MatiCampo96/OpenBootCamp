package ar.org.centro8.curso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase5Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase5Application.class, args);
	}

}
