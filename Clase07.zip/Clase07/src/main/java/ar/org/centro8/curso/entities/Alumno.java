package ar.org.centro8.curso.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="alumnos")
public class Alumno {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, nullable = false)
    private int id;
    
    @Column(name = "nombre")
    private String nombre;

    @Column(name = "apellido")
    private String apellido;

    @Column(name = "edad")
    private int edad;

    @Column(name = "id_curso")
    private int id_curso;
    
    public Alumno() {
    }

    public Alumno(String nombre, String apellido, int edad, int id_curso) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.id_curso = id_curso;
    }

    public Alumno(int id, String nombre, String apellido, int edad, int id_curso) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.id_curso = id_curso;
    }

    @Override
    public String toString() {
        return "Alumno [apellido=" + apellido + ", edad=" + edad + ", id=" + id + ", id_curso=" + id_curso + ", nombre="
                + nombre + "]";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getid_curso() {
        return id_curso;
    }

    public void setid_curso(int id_curso) {
        this.id_curso = id_curso;
    }

}
