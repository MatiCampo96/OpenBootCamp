package Coche;

import java.util.List;

public class Coche implements CocheCRUD {
    @Override
    public String toString() {
        return "Coche [marca=" + marca + ", modelo=" + modelo + ", puertas=" + puertas + ", cilindraje=" + cilindraje
                + "]";
    }

    public Coche(String marca, String modelo, int puertas, float cilindraje) {
        this.marca = marca;
        this.modelo = modelo;
        this.puertas = puertas;
        this.cilindraje = cilindraje;
    }

    public Coche() {
    }

    String marca;
    String modelo;
    int puertas;
    float cilindraje;

    @Override
    public void save(Coche coche) {
        // TODO Auto-generated method stub
        System.out.println("coche: " + coche + " guardado");
    }

    @Override
    public void delate(Coche coche) {
        System.out.println("coche: " + coche + " eliminado");
    }

    @Override
    public List<Coche> findAll() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAll'");
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getPuertas() {
        return puertas;
    }

    public void setPuertas(int puertas) {
        this.puertas = puertas;
    }

    public float getCilindraje() {
        return cilindraje;
    }

    public void setCilindraje(float cilindraje) {
        this.cilindraje = cilindraje;
    }

}
