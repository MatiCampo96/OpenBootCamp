package Coche;


public class Main {
     static Coche pancho=new Coche("Zanella", "ARX", 3, 149.01f);
     static CocheCRUD cocheCrud = new Coche("HOnda", "DAS", 3, 13f);
    
    public static void main(String[] args) {
        System.out.println(pancho);
        System.out.println(pancho.toString());
        pancho.save(pancho);

        System.out.println(cocheCrud);
    }
    


    
}
