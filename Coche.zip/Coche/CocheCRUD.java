package Coche;
import java.util.List;

public interface CocheCRUD {
    void save(Coche coche);
   void delate(Coche coche);
   List<Coche> findAll();

    
}
