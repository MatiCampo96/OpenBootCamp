import funciones

n1 = int(input("Ingrese un numero: "))
n2 = int(input("Ingrese un segundo numero: "))
print(":: operaciones Matematicas :: ")
print("""
1- Sumar
2- Restar
3- Multiplicar
4- Dividir
""")
opcion=int(input("Ingrese la operacion a realizar: "))
if opcion==1:
	print(funciones.sumar(n1, n2))
elif opcion==2:
	print(funciones.restar(n1, n2))
elif opcion==3:
	print(funciones.multiplicar(n1, n2))
elif opcion==4:
	print(funciones.dividir(n1, n2))
else: print("opcion ingresada invalida")