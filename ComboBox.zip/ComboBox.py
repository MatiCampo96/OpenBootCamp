import tkinter as tk
from tkinter import ttk

ventana = tk.Tk()
ventana.geometry("300x300")
ventana.title("Combobox")

lblNum = tk.Label(ventana, text="Seleccione un numero:")
lblNum.place(x=100, y=40)

combo = ttk.Combobox(ventana)
combo.place(x=100, y=70)
combo["values"]=("1","2","3","4","5","6","7","8","9","10","11","12")
combo.current(0)

ventana.mainloop()