import java.util.Scanner;

public class precio {
    public static void main(String[] args) {
        int precio=0;
        int precioIva=0;
        Scanner tecla = new Scanner(System.in);

        System.out.println("Ingrese un precio: ");
        precio = tecla.nextInt();
        tecla.close();

        precioIva = (int) (precio*1.21);

        System.out.println("Su precio con IVA es de: "+precioIva);

    }
    
}
