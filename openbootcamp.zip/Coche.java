
public class Coche {
    public int puertas=0;
    public Coche(int puertas) {
        this.puertas = puertas;
    }
public void agregarPuertas(){
    this.puertas++;
}
    public static void main(String[] args) {
        Coche miCoche= new Coche(4);
        miCoche.agregarPuertas();
        System.out.println(miCoche.puertas);
}
}
